package aS05_Java;

public class Comparestrings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Sachin";  
		   String s2="SachinTendulkar";  
		   
		   System.out.println(s1.compareTo(s2));
		   System.out.println(s2.compareTo(s1));
		   
	}

}
