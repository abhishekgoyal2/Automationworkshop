package aS05_Java;

public class ConcatenateString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str =  "best";
		String str1 ="student";
//		String str2= str1.concat(str);
		String str2= str+str1;
		
		System.out.println(" "+str2);
		


}
}
