package CoreJavaASO4;

import java.io.IOException;

public class EvenOdd {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
int n = 4; 
		
		

if (n%2==0)
{
	System.out.print(n +" number is even");

}

else
{
	System.out.print(n + " number is odd");
}
	}

}
