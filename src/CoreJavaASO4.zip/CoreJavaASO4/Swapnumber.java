package CoreJavaASO4;

public class Swapnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=3,y=-2;
		System.out.println("value of x before swapping =" +x+" "+ " value of y before swapping = "+y);
		y=y-x;
		x=y+x;
		y=x-y;
System.out.println("numbers are swapped " +"value of x after swapping =" +x+" "+ " value of y after swapping = "+y);
	}

}
