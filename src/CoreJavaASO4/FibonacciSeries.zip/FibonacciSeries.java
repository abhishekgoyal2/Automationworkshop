package CoreJavaASO4;

public class FibonacciSeries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int fib1=0;
		int fib=0;
		for(int i=0;i<10;i++)
					{
			
			fib=fib+i;
			
			
			System.out.println("this is fibonnaci series"+fib);
			
			
		}
		

	}

}
