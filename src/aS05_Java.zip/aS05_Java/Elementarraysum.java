package aS05_Java;

public class Elementarraysum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
