package aS05_Java;

public class Reversenum_forwhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
