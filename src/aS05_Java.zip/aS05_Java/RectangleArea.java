package aS05_Java;

public class RectangleArea {

}
